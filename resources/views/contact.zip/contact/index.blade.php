@extends('layouts.back')
@section('title', 'Contact')
@section('content')
<section class="section">
    <div class="section-header">
      <h1>Contact</h1>
      <div class="section-header-breadcrumb">
        <div class="breadcrumb-item active"><a href="{{ route('contact') }}">Contact</a></div>
      </div>
    </div>
    <div class="section-body">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                <div class="table-responsive">
                <table class="table table-striped" id="customers">
                  <tr>
                    <th scope="col">S#</th>
                    <th scope="col">Name</th>
                    <th scope="col">phone</th>
                    <th scope="col">Email</th>
                    <th scope="col">Subjetc</th>
                    <th scope="col">Action</th>
                  </tr>
                  @forelse ($users as $user)
                <tr>
                    <td scope="row">{{ $loop->iteration }}</td>
                    <td>{{ $user->name }}</td>
                    <td>{{ $user->phone }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->subject }}</td>
                    <td>
                        <i class="fa fa-eye" aria-hidden="true"></i>
                    </td>
                </tr>
                @empty
                    <td colspan="5">
                        <span class="text-danger">
                            <strong>No User Found!</strong>
                        </span>
                    </td>
                @endforelse
                </table>
                {{ $users->links() }}
              </div>
            </div>
            </div>
        </div>
    </div>
</section>
@endsection
