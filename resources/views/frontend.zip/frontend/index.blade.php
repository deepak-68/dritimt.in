@extends('layouts.front')
@section('title', 'UG, PG Admission 2026-27 | DR IT Group')
@section('content')
    <!-- main swiper -->
    <section class="main-banner-section">

        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-7 hero-text">

                    <p class="welcome">WELCOME TO DR IT GROUP OF COLLEGES</p>

                    <h1 class="text-white">
                        Intelligence +<br> Character
                    </h1>

                    <h5 class="subtext">
                        That Is The Goal Of True Education
                    </h5>

                    <p class="text-white mb-2">Dr IT Group of Colleges - Shaping Future Leaders</p>

                    <a href="{{ url('register-online') }}" class="btn btn-brochure">Apply Now</a>
                    <a href="{{ url('post-graduate') }}" class="btn btn-brochure">Explore</a>

                </div>


                <div class="col-lg-4 offset-lg-1">

                    <div class="enquiry-box">

                        <h5>Quick Enquiry</h5>
                        <p class="text-cccc mb-2">We'll call you back shortly</p>
                        @if(session('success'))
                            <div class="alert alert-success">
                                {{ session('success') }}
                            </div>
                        @endif
                        <form action="{{ route('enquiry.store') }}" method="POST">
                            @csrf

                            <input type="text" name="name" class="form-control" placeholder="Your Name">
                            @error('name')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                            <input type="tel" name="phone" class="form-control" placeholder="Phone Number" maxlength="10"
                                oninput="this.value = this.value.replace(/[^0-9]/g, '')" required>
                            @error('phone')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror

                            <select class="form-control" name="course" required>
                                <option value="">Select Course</option>

                                <option value="BCA">BCA</option>
                                <option value="BBA ">BBA </option>
                                <option value="B.Com(hons)">B.Com (Hons)</option>
                                <option value="B.Sc. MLS">B.Sc. MLS</option>
                                <option value="B.Sc. Radiology">B.Sc. Radiology</option>
                                <option value="B.Tech (CS)">B.Tech (CS)</option>
                                <option value="B.Tech (MECH)">B.Tech (MECH)</option>
                                <option value="B.Tech (EE)">B.Tech (EE)</option>
                                <option value="B.Tech (AI & ML)">B.Tech (AI & ML)</option>
                                <option value="MBA">MBA</option>
                                <option value="MCA">MCA</option>
                            </select>

                            <button type="submit" class="btn btn-brochure w-100">
                                Submit Enquiry
                            </button>
                        </form>

                        <!-- <div class="single-schedule last" id="home-contact-form">
                                                                                    <div class="inner">
                                                                                        @if ($errors->any())
                                                                                            @foreach ($errors->all() as $error)
                                                                                                <div class="text-danger text-center">{{$error}}</div>
                                                                                            @endforeach
                                                                                        @endif
                                                                                        @if(session()->has('success'))
                                                                                            <div class="text-success text-center">
                                                                                                {{ session()->get('success') }}
                                                                                            </div>
                                                                                        @endif
                                                                                        @if(session()->has('error'))
                                                                                            <div class="text-danger text-center">
                                                                                                {{ session()->get('error') }}
                                                                                            </div>
                                                                                        @endif
                                                                                        <div class="single-content">


                                                                                            <form class="form" method="post" action="{{ route('student.contact') }}"
                                                                                                accept-charset="UTF-8">
                                                                                                <input name="_token" type="hidden" value="{{ csrf_token() }}" />
                                                                                                <div class="row">
                                                                                                    <div class="col-lg-12">
                                                                                                        <div class="form-group">
                                                                                                            <input type="text" name="name" placeholder="Name"
                                                                                                                value="{{ old('name') }}" required="">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-lg-12">
                                                                                                        <div class="form-group">
                                                                                                            <input type="email" name="email" placeholder="Email"
                                                                                                                value="{{ old('email') }}" required="">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-lg-12">
                                                                                                        <div class="form-group">
                                                                                                            <input type="number" name="phone" id="phone" placeholder="Phone"
                                                                                                                value="{{ old('phone') }}" required=""><span
                                                                                                                id="spnPhoneStatus"></span>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-lg-12">
                                                                                                        <div class="form-group">
                                                                                                            <input type="text" name="subject" placeholder="Subject"
                                                                                                                value="{{ old('subject') }}" required="">
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-lg-12">
                                                                                                        <div class="form-group">
                                                                                                            <textarea name="message" rows="2" placeholder="Your Message"
                                                                                                                required="">{{ old('message') }}</textarea>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="col-12">
                                                                                                        <div class="form-group login-btn">
                                                                                                            <button class="btn btn-brochure" type="submit">Send</button>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </form>

                                                                                        </div>
                                                                                    </div>
                                                                                </div> -->

                    </div>

                </div>

            </div>
        </div>

    </section>

    <!-- about us section  -->
    <section class="about-section">
        <div class="container">

            <div class="row align-items-center">

                <!-- LEFT IMAGE -->
                <div class="col-lg-6 mb-4 mb-lg-0">

                    <div class="about-img">

                        <img src="{{ asset('frontend/img/about-2.jpg') }}" class="img-fluid">

                        <div class="experience-box">
                            <h4 class="text-white">25+</h4>
                            <span>Years of Excellence</span>
                        </div>

                    </div>

                </div>


                <!-- RIGHT CONTENT -->
                <div class="col-lg-6">

                    <span class="tag">ABOUT US</span>

                    <h2 class="home_about_title">
                        Where Learning Meets Opportunity
                    </h2>

                    <p class="home_about_text" align="justify">
                        When it comes to quality education, Dr. IT Group of Colleges stands as a trusted and reputed name.
                        The institution operates under the esteemed Dr. ITM Limited Group, an ISO 9001:2015 certified
                        organization, ensuring high standards in both education and management.
                        Dr. IT Group of Colleges is located in the serene, eco-friendly, and pollution-free environment of
                        Banur, near Chandigarh. This peaceful setting provides an ideal atmosphere for learning and
                        contributes to the overall development of students, making it a perfect place for academic
                        growth.<br>
                        The teaching-learning process at the institution is supported by modern infrastructure and
                        innovative methodologies. The focus is on delivering a balanced and holistic education that enhances
                        both academic knowledge and practical skills, preparing students for real-world challenges.
                        A key strength of Dr. IT Group of Colleges lies in its commitment to student success. The
                        institution not only imparts quality education but also actively supports students in securing job
                        opportunities. With dedicated placement assistance, students and their guardians can be assured of
                        strong career guidance and support for a successful future.


                    </p>





                    <div class="contact-box">

                        <span>Admission Helpline</span>
                        <h5><a href="tel:+919216798705">+91 92167-98705</a></h5>

                    </div>

                </div>

            </div>
        </div>
    </section>
    <!-- about chairman  -->
    <section class="chairman-section">
        <div class="container">

            <div class="section-heading text-center">
                <p class="tag">LEADERSHIP</p>
                <h2>Chairman's Message</h2>
            </div>

            <div class="chairman-card">

                <div class="row g-0 align-items-center">

                    <!-- LEFT IMAGE -->
                    <div class="col-lg-4">
                        <div class="chairman-img">
                            <img src="{{ asset('frontend/img/chairman.jpg') }}" class="img-fluid h-100">
                        </div>
                    </div>

                    <!-- RIGHT CONTENT -->
                    <div class="col-lg-8">

                        <div class="chairman-content">

                            <div class="quote-icon">❝</div>

                            <p class="text-cccc">
                                Dear Students
                            </p>

                            <p class="text-cccc">
                                Our goal is simple. We want to grow and be leaders. We are a business school. We want to
                                help you become leaders who can succeed anywhere. We think it is important to develop your
                                spirit and your profession. We help you gain insights, ethics and sharp thinking. These will
                                help you in todays changing world.
                            </p>
                            <p class="text-cccc"> We invite you to join us on this journey.</p>

                            <h5 class="chairman-name">Man Mohan Kamal Mahajan</h5>
                            <p class="designation">Chairman, Dr IT Group of Colleges</p>

                            <div class="chairman-stats">

                                <div class="stat">
                                    <h4>25+</h4>
                                    <p>Years of Vision</p>
                                </div>

                                <div class="stat">
                                    <h4>5000+</h4>
                                    <p>Students Mentored</p>
                                </div>

                                <div class="stat">
                                    <h4>34 lac</h4>
                                    <p>Highest Placement</p>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>
    <!-- counter -->
    <!-- <section class="stats-section">
                    <div class="container">
                        <div class="row text-center">

                            <div class="col-md-3 col-6 stat-box">
                                <h2 class="counter text-white" data-target="5000">0</h2>
                                <p class="text-white">Students Enrolled</p>
                            </div>

                            <div class="col-md-3 col-6 stat-box">
                                <h2 class="counter text-white" data-target="200">0</h2>
                                <p class="text-white">Faculty Members</p>
                            </div>

                            <div class="col-md-3 col-6 stat-box">
                                <h2 class="counter text-white" data-target="95">0</h2>
                                <p class="text-white">Placement Rate</p>
                            </div>

                            <div class="col-md-3 col-6 stat-box">
                                <h2 class="counter text-white" data-target="100">0</h2>
                                <p class="text-white">Recruiting Companies</p>
                            </div>

                        </div>
                    </div>
                </section> -->
    <!-- academic program  -->

    <section class="courses-section">
        <div class="container">

            <div class="section-title text-center">
                <span class="tag">ACADEMIC PROGRAMS</span>
                <h2>Most Demanding & Popular Courses</h2>
            </div>

            <div class="row g-4">

                <!-- Course Card -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="course-card">

                        <img src="{{ asset('frontend/img/01.jpg') }}" class="img-fluid">

                        <div class="course-content">

                            <span class="badge badge-green">Postgraduate</span>

                            <h5>MCA </h5>

                            <p>It is a postgraduate track that concentrates on coming up.....</p>

                            <div class="course-footer">
                                <span><i class="fa fa-clock"></i> 2 Years</span>
                                <a href="{{url('post-graduate')}}">View Details →</a>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="course-card">

                        <img src="{{ asset('frontend/img/course-04.jpg') }}" class="img-fluid">

                        <div class="course-content">

                            <span class="badge badge-blue">Undergraduate</span>

                            <h5>BBA  </h5>

                            <p> These are a group of undergraduate courses that aim at equipping ....</p>

                            <div class="course-footer">
                                <span><i class="fa fa-clock"></i> 3 Years</span>
                                <a href="{{url('under-graduate')}}">View Details →</a>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="course-card">

                        <img src="{{ asset('frontend/img/course-02.jpg') }}" class="img-fluid">

                        <div class="course-content">

                            <span class="badge badge-blue">Undergraduate</span>

                            <h5>BCA</h5>

                            <p>This is an undergraduate course through which the students learn about programming....</p>

                            <div class="course-footer">
                                <span><i class="fa fa-clock"></i> 3 Years</span>
                                <a href="{{url('under-graduate')}}">View Details →</a>
                            </div>

                        </div>
                    </div>
                </div>


                <div class="col-lg-3 col-md-6 mb-4">
                    <div class="course-card">

                        <img src="{{ asset('frontend/img/course-03.jpg') }}" class="img-fluid">

                        <div class="course-content">

                            <span class="badge badge-blue">Undergraduate</span>

                            <h5>B.Sc (MLS)</h5>

                            <p>How it is laid out: Three years' training in medical laboratory science.....</p>

                            <div class="course-footer">
                                <span><i class="fa fa-clock"></i> 3 Years</span>
                                <a href="{{url('under-graduate')}}">View Details →</a>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- events section -->
    <section class="news-section">
        <div class="container">

            <div class=" section-header section-title">
                <div>
                    <span class="tag">WHAT'S NEW</span>
                    <h2>Latest Events</h2>
                </div>


            </div>

            <div class="row g-4 mt-3">

                <!-- News Card -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="news-card">

                        <img src="{{ asset('frontend/img/holi.jpeg') }}" class="img-fluid">

                        <div class="news-content">

                            <span class="news-tag">Celebration</span>

                            <h5>Holi Celebration </h5>

                            <p class="news-date">March 04, 2026</p>

                            <p align="justify">Holi was celebrated with great enthusiasm at Dr. IT Group of Colleges, spreading colors of
                                joy and unity. </p>

                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="news-card">

                        <img src="{{ asset('frontend/img/drit-01.jpg') }}" class="img-fluid">

                        <div class="news-content">

                            <span class="news-tag">Conference</span>

                            <h5>International Conference </h5>

                            <p class="news-date">March 12, 2026</p>

                            <p align="justify">The International Conference on Sustainable Growth brought together experts and academicians
                                for insightful discussions.</p>

                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="news-card">

                        <img src="{{ asset('frontend/img/lohri.jpg') }}" class="img-fluid">

                        <div class="news-content">

                            <span class="news-tag">Celebration</span>

                            <h5>Lohri Celebration </h5>

                            <p class="news-date">January 5, 2026</p>

                            <p align="justify">Lohri was celebrated with traditional zeal, featuring a bonfire and cultural performances.
                            </p>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- our recruiters -->
    <section class="recruiters-section">
        <div class="container">

            <div class="text-center section-header section-title">
                <span class="tag">PLACEMENT</span>
                <h2>Our Recruiters</h2>
                <p>Top companies that hire our graduates</p>
            </div>

            <div class="row g-3 justify-content-center">

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/ACC.png') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img
                                src="{{ asset('frontend/img/recruiter/AMBUJA.png') }}" alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/BAJAJ.png') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/BHEL.jpg') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img
                                src="{{ asset('frontend/img/recruiter/Federel.png') }}" alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img
                                src="{{ asset('frontend/img/recruiter/Godrej.png') }}" alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/HCL.png') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">

                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/HDFC.png') }}"
                                alt="img">
                        </div>

                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/Magma.png') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img src="{{ asset('frontend/img/recruiter/Pepsi.jpg') }}"
                                alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img
                                src="{{ asset('frontend/img/recruiter/Vardhman.jpg') }}" alt="img">
                        </div>
                    </div>
                </div>

                <div class="col-lg-2 col-md-3 col-6">
                    <div class="recruiter-card">
                        <div class="tag  bg-theme rounded-circle"><img
                                src="{{ asset('frontend/img/recruiter/Vodafone.png') }}" alt="img">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    <!-- placement section -->
    <section class="placement-section">
        <div class="container">

            <div class="section-header section-title ">
                <div>
                    <span class="tag">CAREER SUCCESS</span>
                    <h2 class="text-white">Placement Highlights</h2>
                </div>


            </div>


            <!-- Placement Stats -->
            <div class="row g-4 mt-2">

                <div class="col-lg-3 col-md-6">
                    <div class="placement-stat">
                        <div class="icon">🎓</div>
                        <h4 class="text-white"><span class="counter text-white" data-target="2000">0</span>+</h4>
                        <p class="text-cccc">Students Enrolled</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="placement-stat">
                        <div class="icon">🏢</div>
                        <h4 class="text-white"><span class="counter text-white" data-target="150">0</span>+</h4>
                        <p class="text-cccc">Faculty Members</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="placement-stat">
                        <div class="icon">📈</div>
                        <h4 class="text-white"><span class="counter text-white" data-target="950">0</span>+</h4>
                        <p class="text-cccc">Placement Rate</p>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="placement-stat">
                        <div class="icon">🏆</div>
                        <h4 class="text-white"><span class="counter text-white" data-target="100">0</span>+</h4>
                        <p class="text-cccc">Recruiting Companies</p>
                    </div>
                </div>

            </div>


            <!-- Student Placements -->
            <div class="row g-4 mt-4">

                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="placement-card">

                        <div class="stars">★★★★★</div>

                        <div class="student">
                            <div class="avatar">RS</div>

                            <div>
                                <h6 class="text-cccc">Rahul Sharma</h6>
                                <p class="text-cccc">MCA 2024</p>
                            </div>
                        </div>

                        <p class="company">HCL Technologies - ₹6.5 LPA</p>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="placement-card">

                        <div class="stars">★★★★★</div>

                        <div class="student">
                            <div class="avatar">PM</div>

                            <div>
                                <h6 class="text-cccc">Priya Mehta</h6>
                                <p class="text-cccc">BCA 2024</p>
                            </div>
                        </div>

                        <p class="company">Goldman - ₹7 LPA</p>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="placement-card">

                        <div class="stars">★★★★★</div>

                        <div class="student">
                            <div class="avatar">AS</div>

                            <div>
                                <h6 class="text-cccc">Arjun Singh</h6>
                                <p class="text-cccc">BCA 2023</p>
                            </div>
                        </div>

                        <p class="company">Wipro - ₹4.5 LPA</p>

                    </div>
                </div>

            </div>

        </div>
    </section>

    <!-- campus highlights -->

    <section class="campus-section">
        <div class="container">

            <div class="text-center section-header section-title">
                <span class="tag">INFRASTRUCTURE</span>
                <h2>Campus Highlights</h2>

                <p>Experience world-class facilities designed to foster learning and creativity.</p>
            </div>

            <div class="row g-4 mt-4">

                <!-- Campus Card -->
                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/class.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6>Classrooms</h6>

                            <p>Spacious, well-equipped classrooms that create comfortable learning environment.</p>

                        </div>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/library.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6> Library</h6>

                            <p>A resource-rich library offering books, journals, and digital materials for academic growth.
                            </p>

                        </div>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/CL.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6>Computer Labs</h6>

                            <p>Modern computer labs with advanced systems and high-speed internet for practical learning.
                            </p>

                        </div>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/Semi.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6>Seminar</h6>

                            <p>A fully equipped seminar hall for interactive sessions, workshops, and presentations.</p>

                        </div>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/GYM.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6>GYM</h6>

                            <p>A well-maintained gym with modern equipment to promote fitness and well-being.</p>

                        </div>

                    </div>
                </div>


                <div class="col-lg-4 col-md-6">
                    <div class="campus-card">

                        <img src="{{ asset('frontend/img/infrastructure/OA.jpg') }}" class="img-fluid">

                        <div class="campus-content">

                            <h6>Open Air Theatre</h6>

                            <p>A vibrant open-air theatre for cultural events, performances, and student activities.</p>

                        </div>

                    </div>
                </div>

            </div>

        </div>
    </section>

@endsection
@push('scripts')
    <script>
        // counter
        const counters = document.querySelectorAll(".counter");

        counters.forEach((counter) => {
            counter.innerText = "0";

            const updateCounter = () => {
                const target = +counter.getAttribute("data-target");
                const count = +counter.innerText;

                const increment = target / 100;

                if (count < target) {
                    counter.innerText = Math.ceil(count + increment);

                    setTimeout(updateCounter, 20);
                } else {
                    counter.innerText = target;
                }
            };

            updateCounter();
        });

    </script>
    <script>
        setTimeout(function () {
            let alertBox = document.querySelector('.alert');
            if (alertBox) {
                alertBox.style.transition = "0.5s";
                alertBox.style.opacity = "0";
                setTimeout(() => alertBox.remove(), 500); // remove after fade
            }
        }, 4000); // 4 seconds
    </script>
    <script>
        document.querySelector("form").addEventListener("submit", function (e) {
            let name = document.querySelector("[name='name']").value.trim();
            let phone = document.querySelector("[name='phone']").value.trim();

            let nameRegex = /^[A-Za-z\s]{3,50}$/;
            let phoneRegex = /^[6-9]\d{9}$/;

            if (!nameRegex.test(name)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Name',
                    text: 'Only letters allowed (min 3 characters)'
                });
                return;
            }

            if (!phoneRegex.test(phone)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Invalid Phone Number',
                    text: 'Enter valid 10-digit number starting with 6-9'
                });
                return;
            }
        });
    </script>
@endpush